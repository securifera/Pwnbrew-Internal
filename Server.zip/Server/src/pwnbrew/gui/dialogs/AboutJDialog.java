/*

Copyright (C) 2013-2014, Securifera, Inc 

All rights reserved. 

Redistribution and use in source and binary forms, with or without modification, 
are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
	this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above copyright notice,
	this list of conditions and the following disclaimer in the documentation 
	and/or other materials provided with the distribution.

    * Neither the name of Securifera, Inc nor the names of its contributors may be 
	used to endorse or promote products derived from this software without specific
	prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER 
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

================================================================================

Pwnbrew is provided under the 3-clause BSD license above.

The copyright on this package is held by Securifera, Inc

*/


/*
 * AboutJDialog.java
 *
 * Created on June 24, 2013, 8:23:11 PM
 */

package pwnbrew.gui.dialogs;

import java.awt.Image;
import javax.swing.JFrame;
import pwnbrew.misc.Constants;
import pwnbrew.utilities.Utilities;



/**
 *
 *  
 */
public class AboutJDialog extends javax.swing.JDialog {

    
    private static final String aboutTitle = "About PwnBrew";
   
    //===========================================================================
    /**
     * Creates new form that is displayed in the center of the screen by default.
     * This can be changed by using one of the {@link #setLocation} methods on the created object.
     * @param parent
     */
    public AboutJDialog( JFrame parent ) {
        super(parent, true);
        initComponents();

        initializeCustomData();

        setLocationRelativeTo( null );
    }



    /**
     * Initializes any custom data to be used on the window.
     */
    private void initializeCustomData() {
        
        setTitle( aboutTitle );
        setAppIconImage( getDefaultAppIcon() );
        setVersionInfo( Constants.CURRENT_VERSION );
//        setReleaseDate( SystemVersionMgr.getReleaseDate() );
        
        Image appIcon = Utilities.loadImageFromJar( Constants.EDITOR_IMG_STR );
//        Image logoImage = Utilities.loadImageFromJar( Constants.SPLASH_IMG_STR );
        
        setAppIconImage(appIcon);
//        setLogoImage(logoImage);

    }
    
    
    
    /**
     * Sets the application version to display on this window.
     *
     * @param version   the version to be displayed
     */
    public void setVersionInfo( String version ) {
        versionValueLabel.setText( version );
    }


//    /**
//     * Sets the application release date to be displayed on this window.
//     *
//     * @param releaseDate   the release date to be displayed
//     */
//    public void setReleaseDate( String releaseDate ) {
//        releaseDateValueLabel.setText( releaseDate );
//    }



    /**
     * Returns the default app icon to display on this dialog.
     * @return  the default app icon to display
     */
    private Image getDefaultAppIcon() {
        Image appIcon = Utilities.loadImageFromJar( Constants.EDITOR_IMG_STR );
        if( appIcon != null ) {
            setIconImage( appIcon );
        }
        return appIcon;
    }

    /**
     * Sets the icon to be used on the window (in the top left of the dialog 
     * and also displayed next to the text on the dialog).
     *
     * @param iconImage   the image to be used on the dialog
     */
    public void setAppIconImage( Image iconImage ) {
        setIconImage( iconImage );
    }

//    /**
//     * Sets the icon to be used on the window (in the top left of the dialog
//     * and also displayed next to the text on the dialog).
//     *
//     * @param iconImage   the image to be used on the dialog
//     */
//    public void setLogoImage( Image logoImage ) {
//        logoImageLabel.setIcon( new ImageIcon( logoImage ) );
//    }


    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        closeButton = new javax.swing.JButton();
        logoImageLabel = new javax.swing.JLabel();
        mainPanel = new javax.swing.JPanel();
        developerValueLabel = new javax.swing.JLabel();
        versionValueLabel = new javax.swing.JLabel();
        versionLabel = new javax.swing.JLabel();
        developerLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setIconImage(null);
        setModal(true);
        setName("aboutDialog"); // NOI18N
        setUndecorated(true);
        setResizable(false);

        closeButton.setText("OK");
        closeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeButtonActionPerformed(evt);
            }
        });

        logoImageLabel.setForeground(new java.awt.Color(0, 0, 255));
        logoImageLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        mainPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        developerValueLabel.setText("<html>Ryan Wincey</html>");

        versionValueLabel.setText("1.0.0.0");

        versionLabel.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        versionLabel.setText("Version: ");

        developerLabel.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        developerLabel.setText("Developer:");

        javax.swing.GroupLayout mainPanelLayout = new javax.swing.GroupLayout(mainPanel);
        mainPanel.setLayout(mainPanelLayout);
        mainPanelLayout.setHorizontalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, mainPanelLayout.createSequentialGroup()
                .addContainerGap(34, Short.MAX_VALUE)
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(versionLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(versionValueLabel))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(developerLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(developerValueLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(103, 103, 103))
        );
        mainPanelLayout.setVerticalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(versionLabel)
                    .addComponent(versionValueLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(developerLabel)
                    .addComponent(developerValueLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(97, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(logoImageLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 329, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(closeButton, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(mainPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(18, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(logoImageLabel)
                .addGap(18, 18, 18)
                .addComponent(mainPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(closeButton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void closeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeButtonActionPerformed
        dispose();
    }//GEN-LAST:event_closeButtonActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton closeButton;
    private javax.swing.JLabel developerLabel;
    private javax.swing.JLabel developerValueLabel;
    private javax.swing.JLabel logoImageLabel;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JLabel versionLabel;
    private javax.swing.JLabel versionValueLabel;
    // End of variables declaration//GEN-END:variables

}
